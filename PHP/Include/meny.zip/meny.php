<!--
Sist endret av Erik 03.03.2017
Sist sett på av Sindre 03.03.2017
-->

<?php
include("mysqlcon.php");
$stmt = $mysqli->prepare("SELECT * FROM vikerfjell.meny ORDER BY rekke");
mysqli_set_charset($mysqli, "UTF8");
$stmt->execute();
$result = $stmt->get_result();

while($row = $result->fetch_assoc()){

  $tekst = $row['tekst'];
  $side = $row['side'];
  echo("<li><a href=$side>$tekst</a></li>");
}
echo("
</ul>
</nav>
</header>
</div>");
?>
